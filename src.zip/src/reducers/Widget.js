export function widgetReducer(state = {}, action) {

	return state;
}
