import { combineReducers } from 'redux';

import {userReducer} from './UsersInfo';
import {widgetReducer} from './widget';

const allReducers = {
  userState: userReducer,
  widgetState: widgetReducer
};

const rootReducer = combineReducers(allReducers);

export default rootReducer;
