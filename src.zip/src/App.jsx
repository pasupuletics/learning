import $ from 'jquery';
import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux';

import 'bootstrap/dist/js/bootstrap.min';
import 'bootstrap/dist/css/bootstrap.css';
import './css/app.css';

import store from './store';
import Router from './router'

ReactDOM.render(
	<Provider store={store}>
		<Router />
	</Provider>,
	document.getElementById('root')
);