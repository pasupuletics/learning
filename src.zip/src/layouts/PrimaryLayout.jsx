import React from 'react'
import { Route, Redirect, Switch} from 'react-router-dom'

import { Home, ContactUs, Header} from '../components'
import { UsersInfo } from '../containers'

const PrimaryLayout = props => {
  return (
    <div className="container">
      <Header />
      <main>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/contactUs" component={ContactUs} />
          <Route path="/usersList" component={UsersInfo} />
          <Redirect to="/" />
        </Switch>
      </main>
    </div>
  )
}

export default PrimaryLayout;
