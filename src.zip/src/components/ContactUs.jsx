import React, {Component} from 'react'

export default class ContactUs extends Component {
	render() {
		return <div>Contact Us</div>
	}
} 