import React, { Component } from 'react';
import { PieChart } from 'react-d3-basic';

export default class UsersChat extends Component {
	constructor(props) {
		super(props);

	    this.chartSeries = [
	      {
	        "field": "West Josiemouth",
	        "name": "West Josiemouth"
	      },
	      {
	        "field": "Annatown",
	        "name": "Annatown"
	      },
	      {
	        "field": "South Eldredtown",
	        "name": "South Eldredtown"
	      },
	      {
	        "field": "Koeppchester",
	        "name": "Koeppchester"
	      }
	    ];
	}

	value(d) {
	    return d.BMI;
	}

    name(d) {
      return d.city;
    }

	render() {
		const generalChartData = this.props.users;
		const width = 700;
	    const height = 400;
	    const innerRadius = 50;

		return (
			<div id="users-chart">
				<PieChart
			      data= {generalChartData}
			      width= {width}
			      height= {height}
			      chartSeries= {this.chartSeries}
			      value = {this.value}
			      name = {this.name}
			      innerRadius = {innerRadius}
			      title = "DOnut"
			    />
			</div>
		)
	}
}