import React from 'react';

const HeaderBanner = () => {
	return (
		<div id="header-banner">Header Banner</div>
	);
}

export default HeaderBanner; 