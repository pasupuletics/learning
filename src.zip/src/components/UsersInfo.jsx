import React, {Component} from 'react'

import UsersList from './UsersList.jsx'
import UsersChart from './UsersChart.jsx'

export default class UsersInfo extends Component {
	render() {
		const users = this.props.users;
		return (
			<div id="users-info">
				<UsersList users={users}/>
				<UsersChart users={users}/>
			</div>
		);
	}
} 