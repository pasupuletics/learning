import React, {Component} from 'react'
import CollapsibleSection from './CollapsibleSection.jsx'

export default class Home extends Component {
	render() {
		return (
			<div>
			Home Page
				<CollapsibleSection 
					title="Collapsile Section One"
					collapsed = "true"
				>
					<div className="container">
						<div className="row">
						  <div className="col-6 col-md-4">.col-6 .col-md-4</div>
						  <div className="col-6 col-md-4">.col-6 .col-md-4</div>
						  <div className="col-6 col-md-4">.col-6 .col-md-4</div>
						  <div className="col-6 col-md-4">.col-6 .col-md-4</div>
						</div>						
					</div>
				</CollapsibleSection>
			</div>
		);
	}
} 