import React, { Component } from 'react'
import cs from 'classnames'

export default class CollapsibleSection extends Component {
	constructor(props) {
		super(props);

		this.state = {
			collapsed: this.props.collapsed
		}
		
		this.toggleSection = this.toggleSection.bind(this);
	}

	toggleSection(e) {
		this.setState({
			collapsed: !this.state.collapsed
		});
	}

	render() {
		const {title, headerTemplate} = this.props;
		const collapsed = this.state.collapsed;

		const collapsibleBtnClassNames = cs(
			'glyphicon',
			{
				'glyphicon-plus' : this.state.collapsed,
				'glyphicon-minus' : !this.state.collapsed
			}
		);

		const collapsibleBodyClassNames = cs(
			'cs',
			'panel-body',
			{
				'collapse' : collapsed
			}
		);

		return (
			<article>
				<div className="panel panel-default">
					<div className="panel-heading">
						<button 
							type="button"
							className="btn btn-default btn-sm"
							data-toggle="collapse"
							 onClick={this.toggleSection}
						>
							<span className={collapsibleBtnClassNames} aria-hidden="true"></span>
						</button>
						<span>{title}</span>
						<span>{headerTemplate}</span>
					</div>
					<div className={collapsibleBodyClassNames}>
					    {this.props.children}
					</div>
				</div>
			</article>
		);
	}
}