import React from 'react';
import HeaderBanner from './HeaderBanner.jsx'
import NavBar from './NavBar.jsx'

const Header = () => {
	return (
		<header>
			<HeaderBanner />
			<NavBar />
		</header>
	);
}

export default Header;