import React from 'react'
import {Link} from 'react-router-dom'

const NavBar = (props) => {
	return (
		<nav className="navbar navbar-default navbar-fixed-top" id="nav-bar-top">
  			<div className="container-fluid">
  				<div className="navbar-header">
					<button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span className="sr-only">Toggle navigation</span>
						<span className="icon-bar"></span>
						<span className="icon-bar"></span>
						<span className="icon-bar"></span>
					</button>
				</div>
  				<div className="collapse navbar-collapse" id="navbar">
  					<ul className="nav navbar-nav">
						<li className="nav-item">
							<Link className="nav-link" to="/">Home</Link>
						</li>
						<li className="nav-item">
							<Link className="nav-link" to="/usersList">Users List</Link>
						</li>
						<li className="nav-item">
							<Link className="nav-link" to="/contactUs">Contact Us</Link>
						</li>
						<li className="nav-item">
							<Link className="nav-link" to="/others">Others</Link>
						</li>
					</ul>
					<form className="navbar-form navbar-right">
						<div className="input-group">
					      <input type="text" className="form-control" placeholder="search by ID" />
					      <div className="input-group-btn">
					        <button className="btn btn-default" type="button">
					        	<span className="glyphicon glyphicon-search"></span>
					        </button>
					      </div>
					    </div>
			      </form>
  				</div>  				
  			</div>
  		</nav>
	);
}

export default NavBar;