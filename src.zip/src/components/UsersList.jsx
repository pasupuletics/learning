import React, {Component} from 'react'

export default class UsersList extends Component {
	render() {
		const users = this.props.users;

		const listItems = users.map((user, index) =>
		    <li key={index}>{user.name}</li>
		);
		
		return <ul>{listItems}</ul>
	}
} 