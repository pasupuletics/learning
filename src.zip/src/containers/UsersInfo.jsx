import React, {Component} from 'react'
import { connect } from 'react-redux'
import UsersInfo from '../components/UsersInfo.jsx'

const mapStateToProps = function(state) {
  return {
    users: state.userState.users
  };
}

export default connect(mapStateToProps)(UsersInfo);