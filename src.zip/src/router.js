import React from 'react'
import { BrowserRouter, Route, IndexRoute } from 'react-router-dom'
import { PrimaryLayout } from './layouts'

export default function Router(props) {
	return (
	  <BrowserRouter>
	    <PrimaryLayout />
	  </BrowserRouter>
	);
}
