var fs = require('fs');
var reactDocs = require('react-docgen');
const externalProptypesHandler = require('react-docgen-external-proptypes-handler');
 
files = ['src/component.js']

let metadata = files.map(path => {
  /* append display name handler to handlers list */
  const handlers = reactDocs.defaultHandlers.concat(externalProptypesHandler(path))

  /* read file to get source code */
  const code = fs.readFileSync(path, 'utf8');
  console.log(code);

  /* parse the component code to get metadata */
  const data = reactDocs.parse(code, null, handlers)
//console.log(JSON.stringify(data, null, 2))

  return data
});

console.log(JSON.stringify(metadata, null, 2));

