const iconNames = ['small', 'large', 'medium'];

export default iconNames;