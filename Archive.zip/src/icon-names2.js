const iconNames2 = ['small2', 'large2', 'medium2'];

export default iconNames2;