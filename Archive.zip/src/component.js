import React from 'react';
import PropTypes from 'prop-types';

/* importing variable iconNames from .js file (js, jsx are supported, json is not) */
import iconNames from './icon-names.js';
import iconNames2 from './icon-names2.js';

const Icon = props => {
  return (<span>ICON</span>);
}

Icon.propTypes = {
  /** Icon name */
  name: PropTypes.oneOf(iconNames).isRequired,
  /** Icon name2 */
  name2: PropTypes.oneOf(iconNames2).isRequired,
/** default Chandra */
  keyChandra: PropTypes.string
}

Icon.defaultProps = {
  /** default Icon name */
  name: iconNames[0],
  /** default Icon name */
  name2: iconNames2[1]
}

export default Icon;